<template>
  <div class="container">
    <User />
  </div>
</template>

<script>
 import User from "./components/User.vue";
export default {
  components: {
    User,
  },
};
</script>

<style >
div.component{
border: 1px solid black;
padding: 30px;
}
p {
  text-align: center;

}
</style>
