<template>
    <div class="component">
User Details
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>
div{
    background-color: lightcoral;
}
</style>