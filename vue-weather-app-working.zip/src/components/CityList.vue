
<script setup>
import { useCitiesStore } from "@/stores/cities";

const store= useCitiesStore()
</script>
<template>
  
  <div>
    <div class="city-list">
        <div class="city-item" v-for="city in store.weatherData" v-bind:key="city.cityName">
            <div class="city-name">
            <h2 v-if="city.stateName">{{ city.cityName }}, {{ city.stateName }}</h2>
            <h2 v-else>{{ city.cityName }}</h2>
            <h3>{{ city.countryAbbreviation }}</h3>
        </div>
        <div class="city-data">
            <p><b>Weather Summary:</b> {{ city.weatherSummary }}</p>
            <p><b>Current Temprature:</b> {{ city.currentTemprature }}</p>
            <p><b>High:</b> {{ city.dailyHigh }}&degF /<b>Low:</b> {{ city.dailyLow }}&degF</p>
        </div>
        </div>
    </div>
    <button type="reset" @click="store.clearAllCities">Clear Cities({{ store.getNumberOfCities }})</button>
  </div>
</template>


<style>
.city-list{
    margin: 1em;
}
.city-item{
    width: 100%;
    padding: 1em;
    margin: 0.5em 0;
    color: lightcoral;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    border-radius: 4px;
    background: lightgray;
    
}
h2,h3{
    color: coral;
}
p{
    font-size: 1.2em;
    color: black;
}
p+p{
    margin-top: 0.5em;
}
</style>