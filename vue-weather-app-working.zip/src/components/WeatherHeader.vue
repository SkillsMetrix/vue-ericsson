<script setup>
const props = defineProps({
  title: String,
});
</script>
<template>
  <header>
    <h5>{{ title }}</h5>
  </header>
</template>
<style scoped>
header {
  margin: auto;
  text-align: center;
  margin-bottom: 2.5em;
}
header h5 {
  font-size: 1.5em;
}
</style>
