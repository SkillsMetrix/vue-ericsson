<template>
   <footer>
    <p><slot name="message">Default Message</slot></p>
    <p><slot name="link"></slot></p>
   </footer>
</template>

<style>
footer{
    text-align: center;
    border-top: 1px solid blue;
}
</style>