<template>
  <div class="container">
    <weather-header v-bind:title="headerTitle"></weather-header>
<weather-content></weather-content>
    <weather-footer class="footer">
      <template v-slot:message>Ericsson Weather Application</template>
      <template v-slot:link
        ><a href=" https://www.ericsson.com">Ericsson India</a></template
      >
    </weather-footer>
    <center><p></p></center>
  </div>
</template>

<script setup>
import { ref } from "vue";
import WeatherFooter from "./components/WeatherFooter.vue";
import WeatherHeader from "./components/WeatherHeader.vue";
import WeatherContent from "./components/WeatherContent.vue";

const headerTitle = ref("Welcome to skillsmetrix Weather App");
</script>

<style>
@import "./assets/base.css";
.container {
  margin: auto;
}
</style>
