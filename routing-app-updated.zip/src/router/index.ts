import { createRouter, createWebHistory, RouteRecordRaw } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import AboutView from '../views/AboutView.vue'

import UserDetails from '@/views/UserDetails.vue'
import NotFound from '@/views/NotFound.vue'
import AboutCompany from '@/views/AboutCompany.vue'
import AboutProject from '@/views/AboutProject.vue'

const loginView = () => import('@/views/Login.vue')
const registerView = () => import('@/views/Registration.vue')

const isAuthenticated = () => {
  return localStorage.getItem('auth') === 'true'

}

const authGuard = ((to: any, from: any, next: any) => {
  if (isAuthenticated()) {
    next()
  } else
    next("/login")

})
const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    name: 'home',
    component: HomeView
  },
  {
    path: '/about',
    name: 'about',
    component: AboutView,
    //beforeEnter: authGuard
    children: [
      {
        path: '/company',
        name: 'company',
        component: AboutCompany,
      },
      {
        path: '/project',
        name: 'project',
        component: AboutProject,
      }

    ]
  },
  {
    path: '/login',
    name: 'login',
    component: loginView
  },
  {
    path: '/register',
    name: 'register',
    component: registerView
  },
  {
    path: '/userdetails/:id',
    name: 'userdetails',
    component: UserDetails,
    props: true
  },
  {
    path: '/old-route',
    redirect: '/about'
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    component: NotFound

  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})
// navigation guard




export default router
