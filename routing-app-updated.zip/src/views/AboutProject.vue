<template>
    <div class="about">
      <h1>This is an about Project</h1>
    </div>
  </template>
  