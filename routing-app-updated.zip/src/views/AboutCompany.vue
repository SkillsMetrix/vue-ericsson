<template>
    <div class="about">
      <h1>This is an about Company</h1>
    </div>
  </template>
  