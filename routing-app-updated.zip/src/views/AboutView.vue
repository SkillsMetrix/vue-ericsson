<template>
  <div>
    <p>Welcome to AboutUs Page</p>
    <hr />
    <nav>
      <router-link to="/project">Project</router-link> |
      <router-link to="/company">Company</router-link>
    </nav>
    <router-view />
  </div>
</template>

<style scoped>
nav {
  padding: 30px;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
}

nav a.router-link-exact-active {
  color: #42b983;
}
</style>
