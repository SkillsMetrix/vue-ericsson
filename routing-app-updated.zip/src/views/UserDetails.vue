<script setup lang="ts">
import {defineProps} from 'vue'

defineProps<{id:string}>()
</script>
<template>
    <div class="about">
      <h1>UserDetails : {{ id }}</h1>
    </div>
  </template>
  