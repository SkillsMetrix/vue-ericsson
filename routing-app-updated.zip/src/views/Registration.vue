<template>
    <div class="about">
      <h1>This is an Register page</h1>
    </div>
  </template>
  