<template>
  <div class="about">
    <h1>This is an Home page</h1>
  </div>
</template>
