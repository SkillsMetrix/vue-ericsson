<template>
    <div class="about">
      <h1>OOPS...!Page not found</h1>
    </div>
  </template>
  