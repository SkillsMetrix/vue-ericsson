<template>
  <div>
    Reciever
    <p>{{ message }}</p>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from "vue";
import eventBus from "./eventBus";
// alternative to data() in usual codes
const message = ref("");

const recieveMessage = (msg: string) => {
  message.value = msg;
};
onMounted(() => {
  eventBus.on("messageEvent", recieveMessage);
});
</script>

<style scoped></style>
