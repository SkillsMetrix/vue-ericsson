<template>
    <div>
<Sender/>
<hr>
<Reciever/>
    </div>
</template>

<script>
import Sender from './Sender.vue';
import Reciever from './Reciever.vue';
    export default {
        components:{
            Sender,
            Reciever
        }
    }
</script>

<style scoped>

</style>