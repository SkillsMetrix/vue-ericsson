<template>
  <div>
    <h2>Sending messages</h2>
    <button @click="sendMessage">Send</button>
  </div>
</template>

<script setup>
import eventBus from "./eventBus";
const sendMessage = () => {
  eventBus.emit("messageEvent", "Mail from sender....!");
};
</script>

<style scoped></style>
