<template>
  <div class="container">
    <User />
    <hr>
    <EventBusApp/>
  </div>
</template>

<script>
 import User from "./components/User.vue";
import EventBusApp from "./eventbus/EventBusApp.vue";
 export default {
  components: {
    User,
    EventBusApp
  },
};
</script>

<style >
div.component{
border: 1px solid black;
padding: 30px;
}
p {
  text-align: center;

}
</style>
