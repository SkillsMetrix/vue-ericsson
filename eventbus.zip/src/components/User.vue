<template>
  <div class="component">
    <h1>The User Component: {{ name }}</h1>
    <button @click="changeName" class="btn btn-primary">Change Name</button>

    <hr />
    <div class="row">
      <div class="col-xs-12 col-sm-6">
        <UserDetails :myName="name" @nameWasReset="name=$event"
        :resetFN="resetName"
        />
      </div>
      <div class="col-xs-12 col-sm-6">
        <UserEdit />
      </div>
    </div>
  </div>
</template>

<script>
import UserDetails from "./UserDetails.vue";
import UserEdit from "./UserEdit.vue";
export default {
  data() {
    return {
      name: "admin",
    };
  },
  methods: {
    changeName() {
      this.name = "Manager";
    },
    resetName(){
        this.name='SHYAM'
    }
  },
  components: {
    UserDetails,
    UserEdit,
  },
};
</script>

<style scoped>
div {
  background-color: lightskyblue;
}
</style>
