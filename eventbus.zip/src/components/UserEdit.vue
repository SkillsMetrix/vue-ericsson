<template>
    <div class="component">
User Edit
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>
div{
    background-color: lightgreen;
}
</style>