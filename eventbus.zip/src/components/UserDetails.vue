<template>
    <div class="component">
        
        <p>User Name: {{ switchName() }}</p>
         <button @click="resetName">Reset Name</button>
        <button @click="resetFN">Reset Name</button>
    </div>
</template>

<script>
 import {defineEmits} from 'vue'
 
export default{
     props: {
        myName:{
           type: String,
        
        },
        
        resetFN : Function
    },
    methods:{
        switchName(){
            return this.myName.split("").reverse().join("")
        },
        resetName(){
            this.Myname='ADMI'

            emits('nameWasReset',this.myName)
        }
    },
   
    
}
</script>

<style scoped>
    div {
        background-color: lightcoral;
    }
</style>