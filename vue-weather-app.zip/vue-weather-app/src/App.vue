<template>
    <div class="container">
    <center><p>Welcome to skillsmetrix Weather App</p></center>   
            </div>
</template>

